from django.apps import AppConfig


class TheWallAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'the_wall_app'
