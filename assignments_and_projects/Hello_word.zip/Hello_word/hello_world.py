print("Hello world")
my_name="omyma"
print("Hello", my_name)
print("Hello"+" "+my_name)
fav_namber=10
print("Hello",fav_namber,"!!")
#print("Hello"+fav_namber+"!!")
food_one="pizza"
food_tow="sushi"
print("I've to eat {} and {} ".format(food_one,food_tow))
print(f"I'vw to eat {food_one} and {food_tow}")

My_age=30
My_daughter_age=8
print(f"Next year I will be {My_age+1} years old. and My daughter will be {My_daughter_age+1} years old")


